$( document ).ready(function() {
    //Declaramos la url del API
    const APIURL = 'http://hp-api.herokuapp.com/api/characters' ;
    //Agregamos un botón con jQuery
    $("body").prepend('<button id="btn1">Personajes Harry Potter</button> ');
    //Escuchamos el evento click del botón agregado
    $("#btn1").click(() => {
             $. ajax({
                 method : "GET",
                 url : APIURL,
                 success: function(respuesta){
                    $("body").append(`
                        <tr> 
                         <th>Personaje &nbsp;</th>
                         <th>Casa &nbsp;</th>
                         <th>Nacimiento &nbsp;</th>`);
                     for(let item of respuesta) {
                        $("body").append(`
                                           <tr>
                                            <td>${item.name} &nbsp;</td>
                                            <td>${item.house} &nbsp; </td>
                                            <td>${item.dateOfBirth} &nbsp; </td>      
                                           </tr>`);
                                        
                     }
                    
              }
         });
     });
    });