$("body").prepend('<button id="btn">¡ Moveme !</button></br>');

$(document).ready(function(){
    $("#btn").click(function(){
        let div = $("#square");
        div.animate({height: '400px'}, "slow");
        div.animate({width: '400px'}, "slow");
        div.animate({height: '200px'}, "slow");
        div.animate({width: '200px'}, "slow");
    });
});

