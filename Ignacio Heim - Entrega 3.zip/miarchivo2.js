alert("¡Vamos a multiplicar todo 10 veces!")

let numero = prompt("Por favor ingresa un numero (para salir escriba ESC)");

while (numero != "ESC") {
    switch (numero) {                    
            case "":
                alert("¿Estás seguro que ingresaste un número?.");
                break;
            default:
            for (i = 1; i <= 10; i++) {
            resultado = i * numero;
                alert("El resultado es: " + resultado);
         }
        }
        numero = prompt("Ingrese otro numero:");
    }