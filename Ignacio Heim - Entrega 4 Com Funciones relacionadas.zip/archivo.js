number = 0

function introduceNumber () {
    number = parseInt(prompt("Por favor introduce un numero:"));
}

function modulus (number) {
    return number % 2;
}

let modulusMessage = ""

function showModolus (modulusMessage) {
    if (modulus(number) == 0) {
        modulusMessage = alert("El numero es par");
    } else {
        modulusMessage = alert("El numero es impar")
    };
}

introduceNumber();
modulus(number);
showModolus(modulusMessage);