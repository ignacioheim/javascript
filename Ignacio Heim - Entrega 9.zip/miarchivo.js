let price = 15000;

document.getElementById("intro").innerHTML = "El precio del producto es: " + price;

let miformulario = document.getElementById ("formulario");

miformulario.addEventListener ("submit", showForm);

function showForm (e) {
    e.preventDefault ();
    let numberChosen = e.target
    let cuotas = numberChosen.children[0].value;
    let cuota = price/cuotas
    document.getElementById("installment").innerHTML = "El valor de la cuota es: $ " + cuota
}


