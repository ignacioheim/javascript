// Saludo de bienvenida a la página
const greeter = () => alert("Bienvenidos a Asian Air. Vas a saber cuánto cuestan los áreaos a las ciudades mas importantes del continente.");
greeter();

// Elección de ciudad
let city = () => prompt("Elige entre Tokio, Shangai, Hong Kong y Singapur.");

let cityChosen = city().replace(/\w\S*/g, (w) => (w.replace(/^\w/, (c) => c.toUpperCase())));

alert("Has elegido " + cityChosen);

// Cantidad de pasajeros. Al menos uno
passengers = 1;

function numbersPassengers () {
  passengers = parseInt(prompt("Ingrese el numero de pasajeros, recordá que se agrega un 5% de descuento por cada persona que se suma (max. 4 pasajeros)"))
}
numbersPassengers();

alert("El número de pasajeros es: " + passengers);

let discount = 1;


function discountRate (passengers) {

    if (passengers == 2) {
        discount = 0.95;
    }
    else if (passengers == 3) {
        discount = 0.90;
    }
    else if (passengers == 4) {
        discount = 0.85;
    }
}

discountRate(passengers);

function priceAir (cityChosen) {
  switch (cityChosen) {
    case "Tokio":
      return (passengers * 32000) * discount;
      break;
    case "Shangai":
       return (passengers * 40000) * discount;
       break;
    case "Hong Kong":
       return (passengers * 45000) * discount;
       break;
    case "Singapur":
       return (passengers * 50000) * discount;
       break;
  }
};

document.getElementById("title").innerHTML = "Resumen";
document.getElementById("city").innerHTML = ("Ciudad elegida " + cityChosen);
document.getElementById("numberPassengers").innerHTML = ("Números de pasajeros " + passengers);
document.getElementById("priceAir").innerHTML = ("Precio total del vuelo " + priceAir(cityChosen));
