let listProducts = [ {id: 1, category: "tablas", product: "BURTON", price: 200 },
                    {id: 1, category: "tablas", product: "NITRO ", price: 150 },
                    {id: 1, category: "tablas", product: "ROSSIGNOL", price: 100 },
                    {id: 1, category: "tablas", product: "SALOMON", price: 230 },
                    {id: 1, category: "tablas", product: "LIB TECH", price: 250 },
                    {id: 1, category: "tablas", product: "JOONES", price: 300 },
                    {id: 2, category: "botas", product: "NIKE", price: 30 },
                    {id: 2, category: "botas", product: "BURTON", price: 70 },
                    {id: 2, category: "botas", product: "DEELUXE", price: 40 },
                    {id: 2, category: "botas", product: "NEXXT", price: 25 },
                    {id: 2, category: "botas", product: "VANS", price: 50 },
                    {id: 3, category: "fijaciones", product: "BURTON", price: 170 },
                    {id: 3, category: "fijaciones", product: "UNION", price: 180 },
                    {id: 3, category: "fijaciones", product: "K2", price: 100 },
                    {id: 3, category: "fijaciones", product: "RIDE", price: 200 },
                    {id: 3, category: "fijaciones", product: "SALOMON", price: 250 },
                    {id: 4, category: "cascos", product: "ALASKA", price: 30 },
                    {id: 4, category: "cascos", product: "OMBAK", price: 40 },
                    {id: 4, category: "cascos", product: "ANON", price: 60 },
                    {id: 5, category: "camperas", product: "DC", price: 90 },
                    {id: 5, category: "camperas", product: "SALOMON", price: 120 },
                    {id: 5, category: "camperas", product: "BILLABONG",price: 80 },
                    {id: 5, category: "camperas", product: "RIPCURL", price: 70 }, ];


// ORDENAR PRODUCTOS POR PRECIO MAYOR A MENOR PRECIO


let chooseCategory = prompt("Ordenar por mayor precio la categoria que selecciones");

let categories = ['tablas', 'botas', 'fijaciones', 'cascos', 'camperas']

if (categories.includes(chooseCategory)) {
  let filterCategory = listProducts.filter(({category}) => chooseCategory.includes(category));
  let descendingProducts = filterCategory.sort((a, b) => (b.price > a.price) ? 1 : -1)

  let descendingCategory = []
  let descendingItems = []
  let descendingPrice = []

  function listDescending () {
    
    for (const item of descendingProducts) {
      descendingCategory.push(item.category.toString());
      descendingItems.push(item.product);
      descendingPrice.push(item.price);
    } 
  };

  listDescending();

  function makeUL(array) {

    let list = document.createElement('ul');

    for (let i = 0; i < array.length; i++) {

      let item = document.createElement('li');

        item.appendChild(document.createTextNode(array[i]));

        list.appendChild(item);
    }

    return list;
  }

  document.getElementById('cat').appendChild(makeUL(descendingCategory));
  document.getElementById('item').appendChild(makeUL(descendingItems));
  document.getElementById('price').appendChild(makeUL(descendingPrice));
  
} else {
  alert("La categoría elegida no existe")
};



