alert("Gracias por visitar nuestro sitio. Antes de empezar necesitamos unas preguntas.")

let nombre = prompt("Por favor ingrese su nombre:")
let apellido = prompt("Por favor ingrese su apellido:")

// Funciones para capitalizar la primer letra del nombre y del apellido.

function nombre_mayus(nombre) {
    return nombre.charAt(0).toUpperCase() + nombre.slice(1);
  }

  function apellido_mayus(apellido) {
    return apellido.charAt(0).toUpperCase() + apellido.slice(1);
  } 

if((nombre == "") || (apellido == "")){
    alert("Algo salió mal. Por favor ingresa tu nombre y apellido.")
    location.reload() // Función para recargar la página automática.
} else {  
    alert("Hola" + " " + nombre_mayus(nombre) + " "  + apellido_mayus(apellido) + ", un placer tenerte aquí.")
};

let numero = parseInt(prompt("Por último te pido que ingreses un número de 0 a 100:"))

if ((numero > 9) && (numero <= 50)) {
  alert("Excelente, has elegido muy bien.");
} else if  (((numero >= 0) && (numero <= 9)) || ((numero >= 51) && (numero <=100))) {
  console.log("El numero elegido fue " + numero);
} else {
  console.log("¿Estás seguro que elegiste un número de 0 a 100?");
}