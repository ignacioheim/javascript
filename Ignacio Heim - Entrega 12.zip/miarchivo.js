$("body").prepend(` <h1></h1>
                    <form id="myForm">
                    <input type="text" placeholder="Nombre" id="name">
                    <input type="text" placeholder="Apellido" id="lastname">
                    <input type="number" placeholder="Edad" id="age">
                    <input type="email" placeholder="Email" id="email">
                    <input type="submit">
                    </form>`);
//Asociamos el evento submit al
$("#myForm").submit(function (e) {
    e.preventDefault();

    let form = $(e.target).children();
    let input1 = form[0].value;
    let input2 = form[1].value;
    let input3 = form[2].value;
    let input4 = form[3].value;
    
    $("body").append(`</br><h1>Resumen de formulario:</h1> <p>${input1}</p>
    <p>${input2}</p>
    <p>${input3}</p>
    <p>${input4}</p>`)
});